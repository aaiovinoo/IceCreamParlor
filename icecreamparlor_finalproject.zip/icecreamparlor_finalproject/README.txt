README Ice Cream Parlor Final Project

by Ashwin Hingwe and Abigail Iovino

Steps to Run:
1. Open "icecreamparlor_finalproject.pde"
2. Click "Run"
3. If error for libraries missing, Sketch>Import Library...>Add Library and install minim
4. Use arrow keys (left and right) to move the cone and catch falling scoops 